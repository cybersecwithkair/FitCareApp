//
//  SOSViewController.swift
//  TheFitCareApp
//
//  Created by Ria Kalachetty on 2/6/2023.
//

import Foundation
import UIKit
import CoreLocation
import MessageUI
import ContactsUI
import Intents
import IntentsUI
import MapKit
import CoreLocationUI



class SOSViewController: UIViewController, MFMessageComposeViewControllerDelegate,CNContactPickerDelegate,INUIAddVoiceShortcutViewControllerDelegate, CLLocationManagerDelegate  {
    @IBOutlet weak var sosButton: UIButton!
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Request location authorization
        locationManager.requestWhenInUseAuthorization()
        
        // Set the delegate
               locationManager.delegate = self
               
               // Start updating location
               locationManager.startUpdatingLocation()
               
               // Configure map view
               mapView.showsUserLocation = true

    }
    @IBAction func selectContactAndCallButtonTapped(_ sender: UIButton) {
        //to open the phonenumbers list
        selectContactAndCall()
    }
    
    @IBAction func sosButtonTapped(_ sender: UIButton) {
        let alert = UIAlertController(title: "SOS Alert", message: "Emergency assistance requested!", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
        
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            if let currentLocation = locationManager.location {
                let latitude = currentLocation.coordinate.latitude
                let longitude = currentLocation.coordinate.longitude
                
                //Get location to send the location via message
                print("Latitude: \(latitude), Longitude: \(longitude)")
                callEmergencyContacts()
                sendSMS(with: "Emergency! I need help! My current location: \(latitude), \(longitude)")
                
            }
        }
        
    }
    //MARK: Location Manager
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
           if let location = locations.last {
               // Update map view with user's current location
               let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
               mapView.setRegion(region, animated: true)
               
               // Stop updating location once it's obtained
               locationManager.stopUpdatingLocation()
           }
       }

    //Default Emergency Contact
    func callEmergencyContacts() {
        if let url = URL(string: "tel://+61415170757") {
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                print("Unable to make a phone call")
            }
        }
    }
    
 
    func sendSMS(with message: String) {
        //send message
        if MFMessageComposeViewController.canSendText() {
            let controller = MFMessageComposeViewController()
            controller.body = message
            controller.recipients = ["+61415170757"]
            controller.messageComposeDelegate = self
            present(controller, animated: true, completion: nil)
        }
    }
    //MARK: MFMessageComposeViewControllerDelegate delegate method
    // Delegate method for MFMessageComposeViewControllerDelegate
    @objc(messageComposeViewController:didFinishWithResult:) func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func pickEmergencyContacts() {
        let contactPicker = CNContactPickerViewController()
        contactPicker.delegate = self
        contactPicker.predicateForEnablingContact = NSPredicate(format: "phoneNumbers.@count > 0")
        present(contactPicker, animated: true, completion: nil)
    }
    
//MARK: SiriShortcut
    
    func activateSiri() {
        let intent = FitCareIntentIntent()
        
        if let shortcut = INShortcut(intent: intent) {
            let viewController = INUIAddVoiceShortcutViewController(shortcut: shortcut)
            viewController.delegate = self
            present(viewController, animated: true, completion: nil)
        }
    }
    
    @IBAction func activateSiriButtonTapped(_ sender: UIButton) {
        activateSiri()
        
    }
    
    func addVoiceShortcutViewController(_ controller: INUIAddVoiceShortcutViewController, didFinishWith voiceShortcut: INVoiceShortcut?, error: Error?) {
        dismiss(animated: true, completion: nil)
        
        if let error = error {
            print("Failed to add voice shortcut: \(error.localizedDescription)")
        } else {
            // Voice shortcut added successfully
            print("Voice shortcut added")
        }
    }
    
    func addVoiceShortcutViewControllerDidCancel(_ controller: INUIAddVoiceShortcutViewController) {
        dismiss(animated: true, completion: nil)
        
        // User cancelled adding voice shortcut
        print("Adding voice shortcut cancelled")
    }
    
    //MARK: Custom Phone Number
    func saveSelectedContacts(_ contacts: String) {
        // Get the path to the Documents directory
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("Failed to get the documents directory.")
            return
        }
        
        // Create the file URL for the plist
        let plistURL = documentsDirectory.appendingPathComponent("PhoneNumber.plist")
        
        // Create a dictionary to hold the contacts
        let dict: [String: Any] = ["SelectedContacts": contacts]
        
        // Write the dictionary to the plist file
        do {
            let data = try PropertyListSerialization.data(fromPropertyList: dict, format: .xml, options: 0)
            try data.write(to: plistURL)
            print("Selected contacts saved to plist.")
        } catch {
            print("Error saving selected contacts to plist: \(error)")
        }
    }
    @IBAction func customizePhoneNumberButtonTapped(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Customize Phone Number", message: nil, preferredStyle: .alert)
        alertController.addTextField { textField in
            textField.placeholder = "Enter phone number"
            textField.text = UserDefaultsManager.shared.phoneNumber
        }
        let saveAction = UIAlertAction(title: "Save", style: .default) { [weak self] _ in
            guard let textField = alertController.textFields?.first,
                  let phoneNumber = textField.text else { return }
            
            UserDefaultsManager.shared.phoneNumber = phoneNumber
//            self?.saveSelectedContacts(phoneNumber)
            
            // Update the plist with the new phone number
               if let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                   let plistURL = documentsDirectory.appendingPathComponent("PhoneNumber.plist")
                   
                   var plistDict: [String: Any] = [:]
                   plistDict["PhoneNumber"] = phoneNumber
                   
                   if let data = try? PropertyListSerialization.data(fromPropertyList: plistDict, format: .xml, options: 0) {
                       try? data.write(to: plistURL)
                   }
               }

            
            // Show success message
            let successAlert = UIAlertController(title: "Success", message: "Phone number saved successfully", preferredStyle: .alert)
            successAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self?.present(successAlert, animated: true, completion: nil)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }
    //MARK: selectContactAndCall
    func selectContactAndCall() {
        let contactPicker = CNContactPickerViewController()
        contactPicker.delegate = self
        contactPicker.predicateForEnablingContact = NSPredicate(format: "phoneNumbers.@count > 0")
        present(contactPicker, animated: true, completion: nil)
    }
}



    func loadSelectedContacts() -> [String] {
        // Get the path to the Documents directory
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("Failed to get the documents directory.")
            return []
        }
        
        // Create the file URL for the plist
        let plistURL = documentsDirectory.appendingPathComponent("PhoneNumber.plist")
        
        // Load the dictionary from the plist file
        if let data = try? Data(contentsOf: plistURL),
           let dict = try? PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil) as? [String: Any],
           let contacts = dict["SelectedContacts"] as? [String] {
            return contacts
        }
        
        return [] // Return an empty array if there is an error or no contacts found
    }
    
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contacts: [CNContact]) {
        guard let phoneNumber = contacts.first?.phoneNumbers.first?.value.stringValue else {
            print("Unable to retrieve the selected contact's phone number.")
            return
        }
        
        guard let numberURL = URL(string: "tel://" + phoneNumber) else {
            print("Invalid phone number.")
            return
        }
        
        if UIApplication.shared.canOpenURL(numberURL) {
            UIApplication.shared.open(numberURL)
        } else {
            print("Unable to make a phone call.")
        }
    }
    
//MARK: Summary
/* Which shows the current location of the user and also when tapped on SOS emergency a call is triggered to emergency helpline and a message is sent with the user's location in it. Siri Shortcut can be created and ca be used. Contacts can be customised and call contacts shows all the people in the phone book.
 */

    
    
    

  



   





