//
//  HomePageViewController.swift
//  TheFitCareApp
//
//  Created by Ria Kalachetty on 28/5/2023.
//

import Foundation
import UIKit
//HomePageViewController with all the tab bar items
class HomePageViewController: UITabBarController, UITabBarControllerDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegate = self
    }
}

// MARK: Summary
/*The homepage consists of four main tabs which are :
 1. Info tab - Which shows the human anatomy and when clicked on a particular part shows its symptoms.
 2. SOS Emergency tab - Which shows the current location of the user and also when tapped on SOS emergency a call is triggered to emergency helpline and a message is sent with the user's location in it. Siri Shortcut can be created and ca be used. Contacts can be customised and call contacts shows all the people in the phone book.
 3. First-Aid tab - This tab shows betterHealth website which helps people with emergency tutorials and lets uers search their issue and shows results accordingly.
 4. Maps tab - This tab shows the user's current location and also shows the nearest hospitals within the set radar. When tapped on the hospital it redirects to googlemaps which further sgows directions and further more details about the hospital.
 */
