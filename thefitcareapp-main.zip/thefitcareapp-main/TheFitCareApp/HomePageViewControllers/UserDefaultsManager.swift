//
//  UserDefaultsManager.swift
//  TheFitCareApp
//
//  Created by Ria Kalachetty on 8/6/2023.
//

import Foundation

class UserDefaultsManager {
    static let shared = UserDefaultsManager()
    
    private let phoneNumberKey = "PhoneNumber"
    
    var phoneNumber: String? {
        get {
            return UserDefaults.standard.string(forKey: phoneNumberKey)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: phoneNumberKey)
            
            // Update plist file with the new phone number
            if let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                let plistURL = documentsDirectory.appendingPathComponent("PhoneNumber.plist")
                
                var plistDict: [String: Any] = [:]
                plistDict[phoneNumberKey] = newValue
                
                if let data = try? PropertyListSerialization.data(fromPropertyList: plistDict, format: .xml, options: 0) {
                    try? data.write(to: plistURL)
                }
            }
        }
    }
    
    private init() {
        // Load phone number from plist file on initialization
        if let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            let plistURL = documentsDirectory.appendingPathComponent("PhoneNumber.plist")
            
            if let data = try? Data(contentsOf: plistURL) {
                if let plistDict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
                   let phoneNumber = plistDict[phoneNumberKey] as? String {
                    UserDefaults.standard.set(phoneNumber, forKey: phoneNumberKey)
                }
            }
        }
    }
}
//Responsible for updating the new numbers saved in the plist file.



