//
//  FitCareIntent.swift
//  
//
//  Created by Ria Kalachetty on 5/6/2023.
//

import Foundation
import AppIntents
import CoreLocation
import Intents
//FitCareIntent file created during creating intents
protocol FitCareIntentHandling: AnyObject {
    func handle(intent: FitCareIntentIntent, completion: @escaping (FitCareIntentIntentResponse) -> Void)
}


@available(iOS 16.0, macOS 13.0, watchOS 9.0, tvOS 16.0, *)
struct FitCareIntent: AppIntent, CustomIntentMigratedAppIntent {
    static let intentClassName = "FitCareIntentIntent"

    static var title: LocalizedStringResource = "Fit Care Intent"
    static var description = IntentDescription("")

    @Parameter(title: "Phone Number", default: "Enter phone number")
    var phoneNumber: String?

    @Parameter(title: "Location")
    var location: CLPlacemark?

    static var parameterSummary: some ParameterSummary {
        Summary {
            \.$phoneNumber
            \.$location
        }
    }

    func perform() async throws -> some IntentResult {
        // TODO: Place your refactored intent handler code here.
        return .result()
    }
}

fileprivate extension IntentDialog {
    static var phoneNumberParameterPrompt: Self {
        "Share your phone number"
    }
    
    static func phoneNumberParameterDisambiguationIntro(count: Int, phoneNumber: String) -> Self {
        "There are \(count) options matching '\(phoneNumber)'."
    }
    
    static func phoneNumberParameterConfirmation(phoneNumber: String) -> Self {
        "Just to confirm, you wanted '\(phoneNumber)'?"
    }
    
    static var locationParameterPrompt: Self {
        "Can you describe the location"
    }
    
    static func locationParameterDisambiguationIntro(count: Int, location: CLPlacemark) -> Self {
        "There are \(count) options matching '\(location)'."
    }
    
    static func locationParameterConfirmation(location: CLPlacemark) -> Self {
        "Just to confirm, you wanted '\(location)'?"
    }
}


/* Summary */
