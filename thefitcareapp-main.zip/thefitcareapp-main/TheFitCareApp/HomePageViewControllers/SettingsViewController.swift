//
//  SettingsViewController.swift
//  TheFitCareApp
//
//  Created by Ria Kalachetty on 8/6/2023.
//

import Foundation
import UIKit

class SettingsViewController: UIViewController {

    @IBOutlet weak var aboutMeTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadSettings()
    }
    
    func loadSettings() {
    
     // Load about me text
       //All the references 
        aboutMeTextView.text = "For healthKit : https://developer.apple.com/documentation/healthkit/workouts_and_activity_rings/build_a_workout_app_for_apple_watch, For Deeplink : https://help.short.io/en/articles/4065870-how-to-set-up-deep-links-for-ios,               For Image : https://www.pexels.com/search/Human%20Anatomy/ ,For Places API : https://developers.google.com/maps/documentation/places/web-service/get-api-key, For BetterHealth website :   https://www.betterhealth.vic.gov.au/health/conditionsandtreatments/first-aid-basics-and-drsabcd              "
    }
    
}
//MARK: Summary
/* Shows the References*/
