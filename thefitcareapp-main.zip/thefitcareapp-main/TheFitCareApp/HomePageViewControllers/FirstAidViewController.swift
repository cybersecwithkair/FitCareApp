//
//  FirstAidViewController.swift
//  TheFitCareApp
//
//  Created by Ria Kalachetty on 2/6/2023.
//

import UIKit
import WebKit

class FirstAidViewController: UIViewController, WKNavigationDelegate {
    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webView.navigationDelegate = self
        
        // Load the betterHealth page
        loadBetterHealthpage()
    }
    //MARK: loadBetterHealthPage()
    //setting the url 
    func loadBetterHealthpage() {
        let betterHealthURL = URL(string: "https://www.betterhealth.vic.gov.au")!
        let request = URLRequest(url: betterHealthURL)
        webView.load(request)
    }
    
    
}
//MARK: Summary
/*
 This tab shows betterHealth website which helps people with emergency tutorials and lets uers search their issue and shows results accordingly.
 */
