//
//  MapViewController.swift
//  TheFitCareApp
//
//  Created by Ria Kalachetty on 28/5/2023.


import UIKit
import GoogleMaps
import MapKit
import CoreLocation
import GooglePlaces
import SafariServices

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    let locationManager = CLLocationManager()
    var userLocation: CLLocation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up location manager
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        // Set up map view
        mapView.delegate = self
        mapView.showsUserLocation = true
    }
    
    // MARK: - CLLocationManagerDelegate
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        
        userLocation = location
        
        // Update map view to show user's current location
        let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(region, animated: true)
        
        // Find nearby hospitals
        findNearbyHospitals()
        
        // Stop updating location once have the user's current location
        locationManager.stopUpdatingLocation()
    }
    
    // MARK: - Hospital Data
    
    func findNearbyHospitals() {
        guard let userLocation = userLocation else { return }
        
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = "hospital"
        request.region = mapView.region
        
        let search = MKLocalSearch(request: request)
        search.start { (response, error) in
            guard let mapItems = response?.mapItems else { return }
            
            // Add hospital markers to the map
            for item in mapItems {
                let marker = HospitalMarker(coordinate: item.placemark.coordinate, title: item.name)
                self.mapView.addAnnotation(marker)
            }
        }
    }
    
    // MARK: - MKMapViewDelegate
    //shows hospital marker
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        
        if let marker = annotation as? HospitalMarker {
            let view = mapView.dequeueReusableAnnotationView(withIdentifier: "HospitalMarker") ?? MKMarkerAnnotationView(annotation: marker, reuseIdentifier: "HospitalMarker")
            view.annotation = marker
            view.canShowCallout = true
            view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            return view
        }
        
        return nil
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if let marker = view.annotation as? HospitalMarker {
            openGoogleMapsWeb(with: marker.coordinate)
        }
    }
    
    // MARK: - Deeplink to Google Maps
   //open google maps in web when tapped on the hospital marker info
    func openGoogleMapsWeb(with coordinate: CLLocationCoordinate2D) {
        let urlString = "https://www.google.com/maps/search/?api=1&query=\(coordinate.latitude),\(coordinate.longitude)"
        if let url = URL(string: urlString) {
            let safariViewController = SFSafariViewController(url: url)
            present(safariViewController, animated: true, completion: nil)
        }
    }
}

// Hospital custom annotations
class HospitalMarker: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    
    init(coordinate: CLLocationCoordinate2D, title: String?) {
        self.coordinate = coordinate
        self.title = title
    }
}

// MARK: Summary
/* This tab shows the user's current location and also shows the nearest hospitals within the set radar. When tapped on the hospital it redirects to googlemaps which further sgows directions and further more details about the hospital.
 */

