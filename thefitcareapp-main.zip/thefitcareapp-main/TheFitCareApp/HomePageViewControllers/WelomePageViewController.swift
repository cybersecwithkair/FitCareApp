//
//  WelomePageViewController.swift
//  TheFitCareApp
//
//  Created by Ria Kalachetty on 5/6/2023.
//

import Foundation
import UIKit

class WelcomePageViewController: UIViewController {
    @IBOutlet weak var titleLabel: UILabel!

    @IBOutlet weak var appLogo: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()        
    }

    @IBAction func startButtonTapped(_ sender: UIButton) {
        let userDefaults = UserDefaults.standard
         userDefaults.set(true, forKey: "hasShownWelcomePage")
         
         guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
             return
         }
         
         // Navigate to the main view controller
         let mainViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomePageViewController")
         appDelegate.window?.rootViewController = mainViewController
     
//segue to the home page
        performSegue(withIdentifier: "WelcomeToHome", sender: nil)
    }
}
//MARK: Summary
/*
 The welcome page shows the logo and also welcomes all users. The logo is shown so as to let users remember it the next time they want to search the app and also another reason would be to confirm that this is the intented app the user wants to use.
 */
