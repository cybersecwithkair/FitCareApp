//
//  AnatomyViewController.swift
//  TheFitCareApp
//
//  Created by Ria Kalachetty on 4/6/2023.
//

import Foundation
import UIKit
import SafariServices

struct AnatomyPart {
    let title: String
    let description: String
}

class AnatomyViewController: UIViewController {
    
    
    @IBOutlet weak var anatomyImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
    
//tap gesture recogniser 
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTapGesture(_:)))
        anatomyImageView.addGestureRecognizer(tapGesture)
        anatomyImageView.isUserInteractionEnabled = true
    }
    //MARK: handleTapGesture
    @objc func handleTapGesture(_ sender: UITapGestureRecognizer) {
           let tapLocation = sender.location(in: anatomyImageView)
           let tappedPart = determineTappedPart(at: tapLocation)
           
        //constructing url to have tapped part syptoms shown in web
        let query = "\(tappedPart.title) symptoms" // Construct the search query
        let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let urlString = "https://www.google.com/search?q=\(encodedQuery)"

        if let url = URL(string: urlString) {
            let safariViewController = SFSafariViewController(url: url)
            present(safariViewController, animated: true, completion: nil)
        }

       }
   //MARK: determineTappedPart
       func determineTappedPart(at point: CGPoint) -> AnatomyPart {
           let imageSize = anatomyImageView.bounds.size

           // Define regions for different parts of the anatomy
           let headRegion = CGRect(x: 196, y: 15, width: imageSize.width / 3, height: imageSize.height / 3)
           let torsoRegion = CGRect(x: 220, y: 275, width: imageSize.width / 3, height: imageSize.height / 3)
           let faceRegion = CGRect(x: 150, y: 20, width: imageSize.width / 3, height: imageSize.height / 3)
           let armsRegion = CGRect(x: 30, y: 290, width: imageSize.width / 3, height: imageSize.height / 3)
           let heartRegion = CGRect(x: 230, y: 210, width: imageSize.width / 3, height: imageSize.height / 3)
           let lungsRegion = CGRect(x: 200, y: 250, width: imageSize.width / 3, height: imageSize.height / 3)
           let kidneysRegion = CGRect(x: imageSize.width / 4, y: imageSize.height * 2 / 3, width: imageSize.width / 2, height: imageSize.height / 12)
           let liverRegion = CGRect(x:125 , y: 270, width: imageSize.width / 3, height: imageSize.height / 3)
      
           // Check if the point is within a specific body part region
           if headRegion.contains(point) {
               return AnatomyPart(title: "Head", description: "This is the information for the head")
           } else if torsoRegion.contains(point) {
               return AnatomyPart(title: "Torso", description: "This is the information for the torso")
           } else if faceRegion.contains(point) {
               return AnatomyPart(title: "Face", description: "This is the information for the face")
           } else if armsRegion.contains(point) {
               return AnatomyPart(title: "Arms", description: "This is the information for the arms")
           } else if heartRegion.contains(point) {
               return AnatomyPart(title: "Heart", description: "This is the information for the heart")
           } else if lungsRegion.contains(point) {
               return AnatomyPart(title: "Lungs", description: "This is the information for the lungs")
           } else if kidneysRegion.contains(point) {
               return AnatomyPart(title: "Kidneys", description: "This is the information for the kidneys")
           } else if liverRegion.contains(point) {
               return AnatomyPart(title: "Liver", description: "This is the information for the liver")
           } else {
               return AnatomyPart(title: "Unknown", description: "Unknown part tapped")
           }
       }
   }

//MARK: Summary
/*
 This shows the human anatomy and when clicked on a particular part shows its symptoms.
 */
