//
//  AppDelegate.swift
//  TheFitCareApp
//
//  Created by Ria Kalachetty on 27/5/2023.
//

import UIKit
import Foundation
import GoogleMaps
import GooglePlaces
import CoreLocation

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let userDefaults = UserDefaults.standard
           
           // Check if the welcome page has been shown before
           if userDefaults.bool(forKey: "hasShownWelcomePage") {
               // Welcome page has been shown before, navigate to the main view controller
               let mainViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomePageViewController")
               window?.rootViewController = mainViewController
           } else {
               // Welcome page has not been shown before, navigate to the welcome page
               let welcomeViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "WelcomeViewController")
               window?.rootViewController = welcomeViewController
               userDefaults.set(true, forKey: "hasShownWelcomePage") 
            
           }
        
        //API Keys for googleMaps Services

        GMSServices.provideAPIKey("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")
        GMSPlacesClient.provideAPIKey("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")
        
        let buttonAppearance = UIButton.appearance()
           buttonAppearance.tintColor = .black
           buttonAppearance.setTitleColor(.black, for: .normal)

        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    func applicationWillTerminate(_ app: UIApplication, open url: URL, options:[UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        if (url.scheme == "TheFitCareApp" && url.host == "emergency") {
            if let phoneURL = URL(string: "tel://0415170757"){
                UIApplication.shared.open(phoneURL)
            }
            return true
        }
        return false
    }

    }



